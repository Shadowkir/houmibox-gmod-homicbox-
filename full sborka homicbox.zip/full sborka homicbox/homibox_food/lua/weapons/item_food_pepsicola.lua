SWEP.Base = 'weapon_food_base'

SWEP.PrintName = "Пепси Кола"
SWEP.Author = "Homicbox"
SWEP.Purpose = "Прямой конкурент коле, кому-то вкуснее, кому нет. Самое главное различий нет"
SWEP.Category = "Еда"

SWEP.Slot = 3
SWEP.SlotPos = 3
SWEP.Spawnable = true

SWEP.ViewModel = "models/foodnhouseholditems/sodacan01.mdl"
SWEP.WorldModel = "models/foodnhouseholditems/sodacan01.mdl"


SWEP.Healsound = Sound("usable_items/item_drinkcan_02_drink.wav")
SWEP.Satiety = 0.2
SWEP.EatsCounts = 4

SWEP.DrawWorldModelPos = Vector(3, -2, 0)
SWEP.DrawWorldModelAng = Angle(0, 0, 180)


