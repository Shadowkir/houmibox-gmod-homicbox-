SWEP.Base = 'weapon_food_base'

SWEP.PrintName = "Энергетик 'Монстер'"
SWEP.Author = "Homicbox"
SWEP.Purpose = "Вау это тот самый энергетик из DIRT и Death Stranding. Может вызвать привыкание."
SWEP.Category = "Еда"

SWEP.Slot = 3
SWEP.SlotPos = 3
SWEP.Spawnable = true

SWEP.ViewModel = "models/foodnhouseholditems/sodacanb01.mdl"
SWEP.WorldModel = "models/foodnhouseholditems/sodacanb01.mdl"


SWEP.Healsound = Sound("usable_items/item_drinkcan_02_drink.wav")
SWEP.Satiety = 0.1
SWEP.EatsCounts = 4

SWEP.DrawWorldModelPos = Vector(3, -2, 0)
SWEP.DrawWorldModelAng = Angle(0, 0, 180)

