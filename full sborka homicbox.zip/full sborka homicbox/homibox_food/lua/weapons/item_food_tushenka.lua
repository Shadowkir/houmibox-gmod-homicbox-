SWEP.Base = 'weapon_food_base'

SWEP.PrintName = "Тушёнка"
SWEP.Author = "HOUMIBOX"
SWEP.Purpose = "консерва, с тушёнкой и всё"
SWEP.Category = "Еда2"

SWEP.Slot = 3
SWEP.SlotPos = 3
SWEP.Spawnable = true

SWEP.ViewModel = "models/russian food/banka.mdl"
SWEP.WorldModel = "models/russian food/banka.mdl"


SWEP.Healsound = Sound("usable_items/item_crackers_03_eat.wav")
SWEP.Satiety = 0.1
SWEP.EatsCounts = 4

SWEP.DrawWorldModelPos = Vector(3, -2, -2)
SWEP.DrawWorldModelAng = Angle(180, 0, 0)

