SWEP.Base = 'weapon_food_base'

SWEP.PrintName = "Жареная рыба"
SWEP.Author = "Homicbox"
SWEP.Purpose = "Полезная, ну правда не сильно сытная"
SWEP.Category = "Еда"

SWEP.Slot = 3
SWEP.SlotPos = 3
SWEP.Spawnable = true

SWEP.ViewModel = "models/foodnhouseholditems/fishsteak.mdl"
SWEP.WorldModel = "models/foodnhouseholditems/fishsteak.mdl"


SWEP.Healsound = Sound("usable_items/item_crackers_03_eat.wav")
SWEP.Satiety = 0.15
SWEP.EatsCounts = 6

SWEP.DrawWorldModelPos = Vector(3, -2, -2)
SWEP.DrawWorldModelAng = Angle(90, 0, 90)

