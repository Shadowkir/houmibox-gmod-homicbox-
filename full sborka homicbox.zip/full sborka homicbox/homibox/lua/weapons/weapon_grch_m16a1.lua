SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "M16A1"

SWEP.Author 				= "Colt’s Manufacturing Company"

SWEP.Instructions			= "The American 5.56 mm assault rifle, developed and adopted in the 1960s."

SWEP.Category 				= "SIB Carbines"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 20

SWEP.Primary.DefaultClip	= 20

SWEP.Primary.Automatic		= false

SWEP.Primary.Ammo			= "5.56x45 mm"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 50

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "pwb/weapons/sr25/shoot.wav"

SWEP.Primary.FarSound = "sounds_zcity/sr25/dist.wav"

SWEP.Primary.Force = 20

SWEP.ReloadTime = 2.5

SWEP.ShootWait = 0.085

SWEP.ReloadSounds = {

    [0.1] = {"weapons/m4a4/clipout.wav"},

    [1.3] = {"weapons/m4a4/clipin.wav"},

    [2] = {"weapons/m4a4/cliphit.wav"},

}

SWEP.TwoHands = true

SWEP.Shell = "EjectBrass_556"



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Primary.Automatic = true -- Убедиться, что автоматика отключена

SWEP.BurstMode = true
SWEP.BurstShots = 3          -- Сколько выстрелов в очереди
SWEP.ShotsFired = 3          -- Счётчик выстрелов
SWEP.NextBurstTime = 3       -- Время следующей очереди

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "ar2"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/weapons/w_rif_m16a1.mdl"

SWEP.WorldModel				= "models/weapons/w_rif_m16a1.mdl"



SWEP.addAng = Angle(0,0.7,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-6,1.69,5.4) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1.3

function SWEP:PrimaryAttack()
    if not self:CanPrimaryAttack() then return end
    if self.NextBurstTime > CurTime() then return end

    self.ShotsFired = self.ShotsFired + 1

    self:ShootBullet(
        self.Primary.Damage,
        1,
        self.Primary.Cone,
        self.Primary.Spread
    )

    self:TakePrimaryAmmo(1)
    self:EmitSound(self.Primary.Sound)

    if self.ShotsFired >= self.BurstShots then
        self.NextBurstTime = CurTime() + 0.5 -- Задержка между очередями
        self.ShotsFired = 0
    end

    self:SetNextPrimaryFire(CurTime() + self.ShootWait)
end

function SWEP:Reload()
    if self:GetIronsights() then return end
    if self:IsReloading() then return end

    self.ShotsFired = 0 -- Обнуляем очередь при начале перезарядки
    self:DefaultReload(ACT_VM_RELOAD)
end

function SWEP:CanPrimaryAttack()
    if self:Clip1() <= 0 then
        self:EmitSound("weapons/clipempty_rifle.wav")
        self:Reload()
        return false
    end

    return true
end