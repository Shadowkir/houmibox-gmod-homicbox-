

SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "KRISS Vector 45"

SWEP.Author 				= "Transformational Defense Industries"

SWEP.Instructions			= "A submachine gun developed by Transformational Defense Industries. The KRISS Vector uses a semi-free shutter system that guides the recoil-driven shutter group downwards at a high angle."

SWEP.Category 				= "SIB SMG"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 30

SWEP.Primary.DefaultClip	= 30

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= ".45 acp"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 25

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "sounds_zcity/vector/close.wav"

SWEP.Primary.FarSound = "sounds_zcity/vector/dist.wav"

SWEP.Primary.Force = -10

SWEP.ReloadTime = 2.2

SWEP.ShootWait = 0.055

SWEP.ReloadSounds = {


    [0.1] = {"weapons/p90/clipout.wav"},

    [0.7] = {"weapons/p90/clipin.wav"},

    [1] = {"weapons/p90/cliphit.wav"},

    [1.6] = {"weapons/p90/boltback.wav"},

    [1.8] = {"weapons/p90/boltforward.wav"}
}

SWEP.TwoHands = true

SWEP.ShellRotate = false



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "smg"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/pwb2/weapons/w_vectorsmg.mdl"

SWEP.WorldModel				= "models/pwb2/weapons/w_vectorsmg.mdl"



SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-8,0.76,2.970) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1.3

