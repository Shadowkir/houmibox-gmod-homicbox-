SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Ithaca 37"
SWEP.Author 				= "Ithaca Gun Company"
SWEP.Instructions			= "A magazine shotgun designed by John M. Browning and John Pedersen. The rights to the weapon were sold to Remington Arms."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 4
SWEP.Primary.DefaultClip	= 4
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.035
SWEP.Primary.Damage = 28
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "sounds_zcity/doublebarrel_short/close.wav"
SWEP.Primary.FarSound = "sounds_zcity/doublebarrel_short/dist.wav"
SWEP.Primary.Force = 90
SWEP.ReloadTime = 2.9
SWEP.ShootWait = 0.45
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.2] = {"snd_jack_shotguninsert.wav"},
    [0.7] = {"snd_jack_shotguninsert.wav"},
    [1.2] = {"snd_jack_shotguninsert.wav"},
    [1.7] = {"snd_jack_shotguninsert.wav"},
    [2.2] = {"snd_jack_hmcd_shotpump.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"
SWEP.ShellRotate = false

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb2/weapons/w_ithaca37stakeout.mdl"
SWEP.WorldModel				= "models/pwb2/weapons/w_ithaca37stakeout.mdl"

SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.4,3.6) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5