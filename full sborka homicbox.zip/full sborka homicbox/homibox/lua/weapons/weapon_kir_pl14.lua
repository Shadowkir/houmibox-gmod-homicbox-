SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "PL14"
SWEP.Author 				= "Kalashnikov"
SWEP.Instructions			= "Russian self-loading pistol chambered for 9 × 19 mm Parabellum. In October 2021, the PLC entered service with the Ministry of Internal Affairs of the Russian Federation."
SWEP.Category 				= "SIB Pistols"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 14
SWEP.Primary.DefaultClip	= 14
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "9х19 mm Parabellum"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 70
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "pwb2/weapons/pl14/shot-unsil.wav"
SWEP.Primary.FarSound = "snd_jack_hmcd_smp_far.wav"
SWEP.Primary.Force = 15
SWEP.ReloadTime = 2
SWEP.ShootWait = 0.07
SWEP.ReloadSounds = {
    [0.1] = {"pwb2/weapons/pl14/magout.wav"},
    [0.8] = {"pwb2/weapons/pl14/magin.wav"},
    [1.4] = {"pwb2/weapons/pl14/sliderelease.wav"},
}
------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "revolver"

------------------------------------------

SWEP.Slot					= 1
SWEP.SlotPos				= 2
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb2/weapons/w_pl14.mdl"
SWEP.WorldModel				= "models/pwb2/weapons/w_pl14.mdl"

SWEP.addAng = Angle(0,0.1,0) -- Barrel ang adjust
SWEP.addPos = Vector(0,-2,0) -- Barrel pos adjust
SWEP.SightPos = Vector(-14,0.33,1.3) -- Sight pos
SWEP.SightAng = Angle(-15,2,0) -- Sight ang