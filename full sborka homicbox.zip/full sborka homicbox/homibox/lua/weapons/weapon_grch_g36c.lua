SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "HK G36C"

SWEP.Author 				= "Heckler & Koch"

SWEP.Instructions			= "A family of small arms developed in the early 1990s by the German company Heckler & Koch, under the internal designation HK 50, to replace the well-known HK G3 automatic rifle."

SWEP.Category 				= "SIB Rifles"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 30

SWEP.Primary.DefaultClip	= 30

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "5.56x45 mm"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 39

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "weapons/tfa_ins2/g36a1/g36a1_fp.wav"

SWEP.Primary.FarSound = "weapons/g3sg1/distant01.wav"

SWEP.Primary.Force = 27

SWEP.ReloadTime = 2.5

SWEP.ShootWait = 0.095

SWEP.ReloadSounds = {

    [0.1] = {"weapons/m4a4/clipout.wav"},

    [1.3] = {"weapons/m4a4/clipin.wav"},

    [2] = {"weapons/m4a4/cliphit.wav"},

}

SWEP.TwoHands = true

SWEP.Shell = "EjectBrass_556"

SWEP.ShellRotate = true 



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "ar2"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/bb2/weapons/rifles/g36c/w_g36c.mdl"

SWEP.WorldModel				= "models/bb2/weapons/rifles/g36c/w_g36c.mdl"



SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-5,1.02,6.36) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1.3

