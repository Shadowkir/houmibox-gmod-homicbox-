SWEP.Base = 'salat_base' -- base

SWEP.PrintName              = "PP-19 Bizon"
SWEP.Author                 = "Kalashnikov"
SWEP.Instructions           = "The Model 19 submachine gun was developed in 1993 by V. M. Kalashnikov (son of the designer M. T. Kalashnikov) and Alexey Dragunov (son of E. F. Dragunov) by order of the Ministry of Internal Affairs of the Russian Federation (Ministry of Internal Affairs of Russia)."
SWEP.Category               = "SIB SMG"

SWEP.Spawnable              = true
SWEP.AdminOnly              = false

------------------------------------------

SWEP.Primary.ClipSize       = 64
SWEP.Primary.DefaultClip    = 64
SWEP.Primary.Automatic      = true
SWEP.Primary.Ammo           = "9х18 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 35
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "weapons/bizon/fire01.wav"
SWEP.Primary.FarSound = "weapons/ak47/distant.wav"
SWEP.Primary.Force = 30
SWEP.ReloadTime = 2.8
SWEP.ShootWait = 0.09
SWEP.ReloadSounds = {
    [0.3] = {"weapons/bizon/clipout.wav"},
    [1.3] = {"weapons/bizon/clipin.wav"},
    [1.8] = {"weapons/bizon/boltback.wav"},
    [2.1] = {"weapons/bizon/boltforward.wav"},
}
SWEP.TwoHands = true

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo         = "none"

------------------------------------------

SWEP.Weight                 = 5
SWEP.AutoSwitchTo           = false
SWEP.AutoSwitchFrom         = false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot                   = 2
SWEP.SlotPos                = 0
SWEP.DrawAmmo               = true
SWEP.DrawCrosshair          = false

SWEP.ViewModel              = "models/weapons/w_smg_biz.mdl"
SWEP.WorldModel             = "models/weapons/w_smg_biz.mdl"

SWEP.addAng = Angle(-1.3,0.7,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.365,5.65) -- Sight pos
SWEP.SightAng = Angle(-12,0,0) -- Sight ang

SWEP.Mobility = 1
