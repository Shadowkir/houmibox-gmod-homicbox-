SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Saiga-12"
SWEP.Author 				= "Kalashnikov"
SWEP.Instructions			= "The 12-caliber self-loading rifle manufactured at the Izhevsk Machine-building Plant based on the Kalashnikov assault rifle and designed for commercial and amateur hunting of small, medium-sized animals and birds in areas with any climatic conditions."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 5
SWEP.Primary.DefaultClip	= 5
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.017
SWEP.Primary.Damage = 30
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "sounds_zcity/saiga12/close.wav"
SWEP.Primary.FarSound = "sounds_zcity/saiga12/dist.wav"
SWEP.Primary.Force = 70
SWEP.ReloadTime = 2.2
SWEP.ShootWait = 0.20
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.3] = {"weapons/ak47/clipout.wav"},
    [1.3] = {"weapons/ak47/clipin.wav"},
    [1.8] = {"pwb/weapons/aks74u/boltpull.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb/weapons/w_saiga_12.mdl"
SWEP.WorldModel				= "models/pwb/weapons/w_saiga_12.mdl"

SWEP.addAng = Angle(0,-0.1,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.78,5.4) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5