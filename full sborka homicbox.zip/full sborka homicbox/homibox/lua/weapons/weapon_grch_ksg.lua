SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Kel-Tec KSG"
SWEP.Author 				= "Kel-Tec CNC Inc."
SWEP.Instructions			= "Smoothbore shotgun with a longitudinally sliding forearm (pump-action reloading), built according to the bullpup scheme, the main feature of which is the presence of two parallel tubular magazines located horizontally under the barrel, each of which holds up to 7 rounds of 12 caliber."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 14
SWEP.Primary.DefaultClip	= 14
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.015
SWEP.Primary.Damage = 35
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "weapons/xm1014/fire.wav"
SWEP.Primary.FarSound = "weapons/xm1014/distant.wav"
SWEP.Primary.Force = 70
SWEP.ReloadTime = 7.9
SWEP.ShootWait = 0.5
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.2] = {"snd_jack_shotguninsert.wav"},
    [0.7] = {"snd_jack_shotguninsert.wav"},
    [1.2] = {"snd_jack_shotguninsert.wav"},
    [1.7] = {"snd_jack_shotguninsert.wav"},
    [2.2] = {"snd_jack_shotguninsert.wav"},
    [2.7] = {"snd_jack_shotguninsert.wav"},
    [3.2] = {"snd_jack_shotguninsert.wav"},
    [3.7] = {"snd_jack_shotguninsert.wav"},
    [4.2] = {"snd_jack_shotguninsert.wav"},
    [4.7] = {"snd_jack_shotguninsert.wav"},
    [5.2] = {"snd_jack_shotguninsert.wav"},
    [5.7] = {"snd_jack_shotguninsert.wav"},
    [6.2] = {"snd_jack_shotguninsert.wav"},
    [6.7] = {"snd_jack_shotguninsert.wav"},
    [7.2] = {"snd_jack_hmcd_shotpump.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"
SWEP.ShellRotate = false

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb2/weapons/w_ksg.mdl"
SWEP.WorldModel				= "models/pwb2/weapons/w_ksg.mdl"

SWEP.addAng = Angle(0,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-9.5,0.53,6.15) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang


SWEP.Mobility = 1.5