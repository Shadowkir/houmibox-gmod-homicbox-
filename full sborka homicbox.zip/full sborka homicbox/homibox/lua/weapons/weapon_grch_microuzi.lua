

SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "IMI Micro Uzi"

SWEP.Author 				= "Israel Weapon Industries"

SWEP.Instructions			= "The israeli small-sized submachine gun, further modernization of the Uzi (after the Mini-Uzi). The abbreviation IMI stands for Israel Military Industries, the company that developed and initially produced it (but then absorbed by Israel Weapon Industries). The designation Micro- is given to distinguish it from the IMI Mini Uzi, released earlier, the word Uzi itself comes from the name of its designer Uziel Gal, although Gal himself did not participate in the development of modifications of his invention."

SWEP.Category 				= "SIB SMG"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 30

SWEP.Primary.DefaultClip	= 30

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "9х19 mm Parabellum"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 20

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "sounds_zcity/uzi/close.wav"

SWEP.Primary.FarSound = "sounds_zcity/uzi/dist.wav"

SWEP.Primary.Force = 35

SWEP.ReloadTime = 1.9

SWEP.ShootWait = 0.045

SWEP.ReloadSounds = {

    [0.1] = {"weapons/mac10/clipout.wav"},

    [0.6] = {"weapons/mac10/clipin.wav"},

    [1] = {"weapons/mac10/boltforward.wav"},

    [1.2] = {"weapons/mac10/boltback.wav"},

}

SWEP.TwoHands = true

SWEP.ShellRotate = false



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "Revolver"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/bb2/weapons/smgs/microuzi/w_microuzi.mdl"

SWEP.WorldModel				= "models/bb2/weapons/smgs/microuzi/w_microuzi.mdl"



SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-14,0.0,2.1) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang

