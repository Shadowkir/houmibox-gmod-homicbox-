SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "PTRS"

SWEP.Author 				= " "

SWEP.Instructions			= " "

SWEP.Category 				= "SIB Sniper Rifles"



SWEP.Spawnable 				= false

SWEP.AdminOnly 				= true



------------------------------------------



SWEP.Primary.ClipSize		= 5

SWEP.Primary.DefaultClip	= 5

SWEP.Primary.Automatic		= false

SWEP.Primary.Ammo			= "14.5x114 mm"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 700

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "homigrad/weapons/rifle/loud_rifle.wav"

SWEP.Primary.FarSound = "sounds_zcity/draco/dist.wav"

SWEP.Primary.Force = 400

SWEP.ReloadTime = 6.2

SWEP.ShootWait = 1.5

SWEP.ReloadSounds = {

    [0.1] = {"weapons/tfa_ins2/m3greasegun/m3_boltback.wav"},

    [1] = {"weapons/tfa_ins2/winchester_1894/winchester_round_insert_1.wav"},
    [1.7] = {"weapons/tfa_ins2/winchester_1894/winchester_round_insert_2.wav"},
    [2.4] = {"weapons/tfa_ins2/winchester_1894/winchester_round_insert_3.wav"},
    [3.1] = {"weapons/tfa_ins2/winchester_1894/winchester_round_insert_1.wav"},
    [3.9] = {"weapons/tfa_ins2/winchester_1894/winchester_round_insert_2.wav"},

    [5] = {"weapons/tfa_ins2/m3greasegun/m3_boltback.wav"},
    
    [5.5] = {"weapons/tfa_ins2/ak103/ak103_boltrelease.wav"},

}

SWEP.TwoHands = true

SWEP.Shell = "EjectBrass_338Mag"

SWEP.ShellRotate = false 



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= true

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 20

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "ar2"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/weapons/w_grub_ptrs.mdl"

SWEP.WorldModel				= "models/weapons/w_grub_ptrs.mdl"



SWEP.addAng = Angle(-1.8,-1) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-10,0.19,2.8) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 0.2

