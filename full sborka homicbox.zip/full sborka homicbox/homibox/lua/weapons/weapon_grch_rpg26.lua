SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "RPG-26 (W.I.P)"
SWEP.Author 				= "Bazalt"
SWEP.Instructions			= "A Soviet rocket-propelled anti-tank grenade developed by NPO Bazalt to replace the RPG-22 Netto, in order to increase the combat capabilities of motorized rifle, airborne, and other units."
SWEP.Category 				= "SIB Grenade Launchers"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= true
------------------------------------------

SWEP.Primary.ClipSize		= 1
SWEP.Primary.DefaultClip	= 1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "RPG_Round"
SWEP.Primary.Cone = 0.025
SWEP.Primary.Damage = 1000
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "fas2/rpg26/rpg26_fire1.wav"
SWEP.Primary.Force = 10
SWEP.ReloadTime = 5.2
SWEP.ShootWait = 0.1
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.3] = {"zeron/pable3/reloads/p30_la_rpapa7_inspect_hip_rotate.wav"},
    [1] = {"zeron/pable3/reloads/p30_la_rpapa7_raise_hip_rattle.wav"},
    [2] = {"zeron/pable3/reloads/p30_la_rpapa7_reload_fast_hip_magin.wav"},
    [3.5] = {"zeron/pable3/reloads/p30_la_rpapa7_drop_hip_rattle.wav"},
    [4.5] = {"zeron/pable3/reloads/p30_la_rpapa7_reload_fast_hip_safetyclick.wav"},
}
SWEP.TwoHands = true

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "rpg"

------------------------------------------

SWEP.Slot					= 4
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/weapons/fas2/world/explosives/rpg26.mdl"
SWEP.WorldModel				= "models/weapons/fas2/world/explosives/rpg26.mdl"

SWEP.addAng = Angle(-3.2,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-9,1.05,8.16) -- Sight pos
SWEP.SightAng = Angle(-5,0,0) -- Sight ang


SWEP.Mobility = 1.5

function SWEP:Initialize()
    self.BaseClass.Initialize(self) -- Инициализация базового класса
    self:SetNWFloat("VisualRecoil", 0) -- Начальное значение визуальной отдачи
    self.eyeSpray = Angle(0, 0, 0) -- Эффект дрожания камеры
end

-- Расчет позиции дула
function SWEP:CalculateMuzzlePosition()
    local owner = self:GetOwner()
    if not IsValid(owner) then return owner:GetShootPos(), owner:EyeAngles() end
    
    -- Получаем позицию и угол из модели оружия
    local vm = owner:GetViewModel()
    if not IsValid(vm) then return owner:GetShootPos(), owner:EyeAngles() end
    
    -- Ищем кость дула
    local muzzleBone = vm:LookupBone("muzzle") or vm:LookupBone("barrel") or 0
    local muzzlePos, muzzleAng = vm:GetBonePosition(muzzleBone)
    
    -- Если не получили позицию дула, используем стандартные значения
    if not muzzlePos then
        muzzlePos = owner:GetShootPos()
        muzzleAng = owner:EyeAngles()
    end
    
    -- Применяем корректировки позиции
    muzzlePos = muzzlePos + 
               owner:GetForward() * self.addPos.x +
               owner:GetRight() * self.addPos.y +
               owner:GetUp() * self.addPos.z +
               owner:GetForward() * self.SightPos.x +
               owner:GetRight() * self.SightPos.y +
               owner:GetUp() * self.SightPos.z
    
    -- Применяем корректировки угла
    muzzleAng:RotateAroundAxis(muzzleAng:Right(), self.addAng.p + self.SightAng.p)
    muzzleAng:RotateAroundAxis(muzzleAng:Up(), self.addAng.y + self.SightAng.y)
    muzzleAng:RotateAroundAxis(muzzleAng:Forward(), self.addAng.r + self.SightAng.r)
    
    return muzzlePos, muzzleAng
end

-- Основная атака (выстрел)
function SWEP:PrimaryAttack()
    local owner = self:GetOwner()
    if not IsValid(owner) then return end
    
    -- Проверка прицеливания (ПКМ)
    if not owner:KeyDown(IN_ATTACK2) then
        self:SetNextPrimaryFire(CurTime() + 0.5)
        return
    end
    
    if not self:CanPrimaryAttack() then return end

    -- Применяем эффекты отдачи
    self:SetNWFloat("VisualRecoil", self:GetNWFloat("VisualRecoil") + 3.5)
    if CLIENT and owner == LocalPlayer() then
        self:ShootPunch(self.Primary.Force)
        lastShootSib = CurTime() + 0.25 * self.Primary.Force / 50
        
        -- Эффект отбрасывания камеры
        local punch = Angle(-self.Primary.Force * 0.5, math.Rand(-1, 1) * self.Primary.Force * 0.1, 0)
        self.eyeSpray = self.eyeSpray + punch
        owner:ViewPunch(punch)
    end

    -- Создание ракеты --
    if SERVER then
        local rocket = ents.Create("rpg26_warhead")
        if not IsValid(rocket) then return end

        -- Получаем позицию и угол вылета
        local muzzlePos, muzzleAng = self:CalculateMuzzlePosition()

        rocket:SetPos(muzzlePos)
        rocket:SetAngles(muzzleAng)
        rocket:SetOwner(owner)
        rocket:Spawn()
        rocket:Activate()

        -- Запуск ракеты --
        local phys = rocket:GetPhysicsObject()
        if IsValid(phys) then
            phys:SetVelocity(muzzleAng:Forward() * 2500)
        end

        rocket:Use(owner, owner, USE_ON, 1)

        -- Эффект дымного следа
        timer.Simple(0.01, function()
            if IsValid(rocket) then
                -- Основной густой дым
                rocket.SmokeTrail = util.SpriteTrail(
                    rocket,
                    0,
                    Color(180, 180, 180, 0),
                    true,
                    25,
                    0,
                    5,
                    0.1,
                    "particle/smokesprites_0001.vmt"
                )
                
                -- Дополнительные эффекты
                rocket.TrailEffect = ents.Create("env_rockettrail")
                if IsValid(rocket.TrailEffect) then
                    rocket.TrailEffect:SetPos(rocket:GetPos())
                    rocket.TrailEffect:SetParent(rocket)
                    rocket.TrailEffect:SetLocalAngles(angle_zero)
                    rocket.TrailEffect:Spawn()
                    rocket.TrailEffect:Activate()
                    
                    -- Удаление эффекта через 0.8 секунды
                    timer.Simple(0.8, function()
                        if IsValid(rocket) and IsValid(rocket.TrailEffect) then
                            rocket.TrailEffect:Remove()
                        end
                    end)
                end
            end
        end)

        -- Взрыв при уничтожении --
        function rocket:OnRemove()
            local SelfPos = self:GetPos()
            local PowerMult = 4
            
            -- Эффекты взрыва
            ParticleEffect("pcf_jack_groundsplode_medium", SelfPos, vector_up:Angle())
            util.ScreenShake(SelfPos, 99999, 99999, 1, 3000)
            sound.Play("BaseExplosionEffect.Sound", SelfPos, 120, math.random(90, 110))
            
            for i = 1, 4 do
                sound.Play("explosions/doi_ty_01_close.wav", SelfPos, 140, math.random(80, 110))
            end 

            -- Ожоги на поверхностях
            timer.Simple(0.1, function()
                for i = 1, 5 do
                    local Tr = util.QuickTrace(SelfPos, VectorRand() * 20)
                    if Tr.Hit then
                        util.Decal("Scorch", Tr.HitPos + Tr.HitNormal, Tr.HitPos - Tr.HitNormal)
                    end
                end
            end)

            -- Урон по области
            timer.Simple(0, function()
                local Infl = IsValid(self) and self or game.GetWorld()
                local Att = (IsValid(self) and IsValid(self:GetOwner())) and self:GetOwner() or self or game.GetWorld()
                util.BlastDamage(Infl, Att, SelfPos, 120 * PowerMult, 120 * PowerMult)
                util.BlastDamage(Infl, Att, SelfPos, 20 * PowerMult, 1000 * PowerMult)
            
            -- Добавляем осколки из первого кода
            JMod.FragSplosion(self, SelfPos + Vector(0, 0, 20), 200, 100, 3500, self:GetOwner() or game.GetWorld())
            end)
        end
    end
    
    self:EmitSound(self.Primary.Sound, 100, 100, 1, CHAN_WEAPON)
    self:TakePrimaryAmmo(1)
    self:SetNextPrimaryFire(CurTime() + self.ShootWait)
end

-- Эффект отдачи камеры
function SWEP:ShootPunch(force)
    if not IsValid(self:GetOwner()) or self:GetOwner():IsNPC() then return end
    
    local punch = Angle(-force * 0.5, math.Rand(-1, 1) * force * 0.1, 0)
    self.eyeSpray = self.eyeSpray + punch
    self:GetOwner():ViewPunch(punch)
end

-- Обработка каждого кадра
function SWEP:Think()
    self.BaseClass.Think(self) -- Вызов Think базового класса
    
    -- Затухание отдачи
    if self:GetNWFloat("VisualRecoil") > 0 then
        self:SetNWFloat("VisualRecoil", Lerp(0.1, self:GetNWFloat("VisualRecoil") or 0, 0))
    end
    
    -- Затухание эффекта дрожания камеры
    if CLIENT and IsValid(self:GetOwner()) and self:GetOwner() == LocalPlayer() then
        self.eyeSpray = LerpAngle(0.2, self.eyeSpray, Angle(0, 0, 0))
    end
end

function SWEP:ShootBullet() return end