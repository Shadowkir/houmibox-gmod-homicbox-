

SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "Steyr TMP"

SWEP.Author 				= "Steyr Arms"

SWEP.Instructions			= "The automatic pistol chambered for 9x19 mm Parabellum, manufactured by the Austrian company Steyr Arms."

SWEP.Category 				= "SIB SMG"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 30

SWEP.Primary.DefaultClip	= 30

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "9х19 mm Parabellum"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 20

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "sounds_zcity/tmp/supressor.wav"

SWEP.Primary.Force = 25

SWEP.ReloadTime = 2.2

SWEP.ShootWait = 0.075

SWEP.ReloadSounds = {

    [0.1] = {"weapons/mac10/clipout.wav"},

    [0.8] = {"weapons/mac10/clipin.wav"},

    [1.2] = {"weapons/mac10/boltforward.wav"},

    [1.4] = {"weapons/mac10/boltback.wav"},

}

SWEP.DoFlash = false

SWEP.ShellRotate = false



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 6

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "smg"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/homicbox_weapons/w_smg_tmp.mdl"

SWEP.WorldModel				= "models/homicbox_weapons/w_smg_tmp.mdl"



SWEP.addAng = Angle(-1.2,1.7) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-12,1.3,2.7) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang
