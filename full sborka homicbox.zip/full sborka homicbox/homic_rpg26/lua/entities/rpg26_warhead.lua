AddCSLuaFile()

local ExploSnds = {}
ExploSnds[1]                         =  "weapons/tfa_ww2_piat/piat_detonate_01.wav"
ExploSnds[2]                         =  "weapons/tfa_ww2_piat/piat_detonate_02.wav"
ExploSnds[3]                         =  "weapons/tfa_ww2_piat/piat_detonate_03.wav"

ENT.Spawnable		       	=	false
ENT.AdminSpawnable		   	=	true

ENT.PrintName		      	=	"PIAT"
ENT.Author			      	=	""
ENT.Contact			      	=	""
ENT.Category              	=	"Gredwitch's Stuff"
ENT.Base					=	"base_rocket"

ENT.Model                	=	"models/weapons/fas2/world/explosives/rpg26/rocket.mdl"
ENT.RocketTrail          	=	"ins_rockettrail"
ENT.RocketBurnoutTrail   	=	"grenadetrail"
ENT.Effect               	=	"high_explosive_air"
ENT.EffectAir            	=	"high_explosive_air"
ENT.EffectWater          	=	"water_torpedo"

ENT.StartSound             	=	"helicoptervehicle/missileshoot.mp3"
ENT.ArmSound               	=	""
ENT.ActivationSound        	=	"buttons/button14.wav"
ENT.EngineSound				=	"Hydra_Engine"
ENT.StartSoundFollow		=	true

ENT.ExplosionDamage			=	100
ENT.ExplosionRadius			=	150
ENT.Mass           			=	1.2
ENT.EnginePower    			=	3985 -- 4555
ENT.TNTEquivalent			=	6
ENT.FuelBurnoutTime			=	0.15
ENT.LinearPenetration		=	440
ENT.MaxVelocity				=	950
ENT.Caliber					=	93
ENT.ShellType				=	"HEAT"
-- ENT.RotationalForce			=	250

function ENT:SpawnFunction( ply, tr )
    if (!tr.Hit) then return end
	
    local ent = ents.Create(self.ClassName)
	ent:SetPhysicsAttacker(ply)
	ent.Owner = ply
    ent:SetPos(tr.HitPos + tr.HitNormal * 16) 
    ent:Spawn()
    ent:Activate()
	
    return ent
end

function ENT:DoPreInit()
	self.ExplosionSound = ExploSnds[math.random(#ExploSnds)]
end

