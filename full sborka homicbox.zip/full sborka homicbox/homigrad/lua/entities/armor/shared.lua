ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "huy"

DEFINE_BASECLASS( "base_anim" )

ENT.Spawnable = "true"