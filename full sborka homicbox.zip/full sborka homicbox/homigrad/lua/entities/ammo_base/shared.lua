ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "hg_ammo_base"

ENT.Spawnable = true

ENT.AmmoCount = 10
ENT.AmmoType = "9х19 mm Parabellum" -- 9.19mm parabelum

ENT.Model = "models/props_lab/box01a.mdl"
ENT.ModelScale = 1