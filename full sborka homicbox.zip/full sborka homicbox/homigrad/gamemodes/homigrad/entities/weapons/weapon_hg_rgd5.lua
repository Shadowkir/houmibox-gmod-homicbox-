SWEP.Base = "weapon_hg_granade_base"

SWEP.PrintName = "RGD-5"
--
SWEP.Instructions = "Наступательная ручная граната, относится к противопехотным осколочным ручным гранатам дистанционного действия наступательного типа."
SWEP.Category = "Гранаты"

SWEP.Slot = 4
SWEP.SlotPos = 2
SWEP.Spawnable = true

SWEP.ViewModel = "models/pwb/weapons/w_rgd5.mdl"
SWEP.WorldModel = "models/pwb/weapons/w_rgd5.mdl"

SWEP.Granade = "ent_hgjack_rgd5nade"