SWEP.Base = "weapon_hg_granade_base"

SWEP.PrintName = "Осколочная Граната"
--
SWEP.Instructions = "Оснваная граната комбайнов, имеет очень убойную силу."
SWEP.Category = "Гранаты"

SWEP.Slot = 4
SWEP.SlotPos = 2
SWEP.Spawnable = true

SWEP.ViewModel = "models/weapons/w_grenade.mdl"
SWEP.WorldModel = "models/weapons/w_grenade.mdl"

SWEP.Granade = "ent_hgjack_hl2nade"